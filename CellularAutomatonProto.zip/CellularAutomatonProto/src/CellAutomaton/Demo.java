/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package CellAutomaton;

/**
 *
 * @author Windows
 */
public class Demo {

    public static void main(String[] args) {

        CrossroadNetwork demo = new CrossroadNetwork();
        Roundabout demo2 = new Roundabout();
        RoadEnvironment re = new RoadEnvironment(demo);
    }

}
